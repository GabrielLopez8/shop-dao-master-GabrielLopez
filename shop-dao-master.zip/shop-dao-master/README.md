# SHOP dao
Implementa los DAO con JDBC:

## Configuración
Para crear la base de datos en el contenedor:
- Arranca el contendor de Mysql
- Copia shop.sql a la carpeta de usuario
- Ejecuta el siguiente comando
```bash
docker exec -i instituto mysql -u root -pfederica < shop.sql
```
